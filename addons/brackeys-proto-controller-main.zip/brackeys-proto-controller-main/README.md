# Proto Controller
Simple first-person Character Controller for prototyping games in Godot.

It's designed to be simple.

It has options for:

- Jumping
- Sprinting
- Free-fly mode

## Installation
Drag proto_controller folder into the "addons" folder at the root of your Godot project. If no addons folder, create one manually.

## License
This repo is freely available under the CC0 license. For more info see LICENSE file.
